import MySQLdb as mariadb
from PyQt5 import QtCore, QtGui, QtWidgets
from quick_admin_ui import Ui_QuickAdmin
import sys

class QuickAdminForm(Ui_QuickAdmin):
    def __init__(self, dialog):
        Ui_QuickAdmin.__init__(self)
        self.setupUi(dialog)
        self.conn = mariadb.connect(user='root', passwd='3amatBotMfO', db='Catalogue', use_unicode=True, charset='utf8')
        self.populateArtCombo()
        self.populateAlbCombo()
        self.populateTypeCombo()
        self.populateSourceCombo()
        self.populateAlbumDetails()
        self.setTrackHeaders()

        self.cmbArt.currentIndexChanged.connect(self.populateAlbCombo)
        self.cmbAlb.currentIndexChanged.connect(self.populateAlbumDetails)
        self.tableTracks.itemChanged.connect(self.updateTrackData)
        self.cmbType.currentIndexChanged.connect(self.updateAlbumType)
        self.cmbSource.currentIndexChanged.connect(self.updateSource)

    def updateAlbumType(self):
        alb_id = self.getSelectedAlbum()
        typeid = int(self.cmbType.itemData(self.cmbType.currentIndex()))
        sql = "UPDATE album SET albumtypeid = %s WHERE albumid = %s;"
        cursor = self.conn.cursor()
        cursor.execute(sql, (typeid, alb_id, ))
        self.conn.commit()

    def updateSource(self):
        alb_id = self.getSelectedAlbum()
        typeid = int(self.cmbSource.itemData(self.cmbSource.currentIndex()))
        sql = "UPDATE album SET sourceid = %s WHERE albumid = %s;"
        cursor = self.conn.cursor()
        cursor.execute(sql, (typeid, alb_id, ))
        self.conn.commit()

    def updateTrackData(self, item):
        alb_id = self.getSelectedAlbum()
        row = self.tableTracks.currentRow()
        col = self.tableTracks.currentColumn()
        newdata = item.text()

        if row >= 0:
            disc = int(self.tableTracks.item(row, 0).text())
            track = int(self.tableTracks.item(row, 1).text())

            if col == 2:
                field = "tracktitle"
            elif col == 4:
                field = "bonustrack"

            if field is not None:
                sql = "UPDATE track SET {} = %s WHERE albumid = %s AND disc = %s AND track = %s;".format(field)
                cursor = self.conn.cursor()
                cursor.execute(sql,(newdata, alb_id, disc, track, ))
                self.conn.commit()

    def setTrackHeaders(self):
        headers = ["Disc","Track","Title","Length","Bonus"]
        widths = [40,40,400,60,40]

        for x in range(0,5):
            self.tableTracks.setHorizontalHeaderItem(x, QtWidgets.QTableWidgetItem(headers[x]))
            self.tableTracks.setColumnWidth(x, widths[x])

    def getSelectedArtist(self):
        art_id = int(self.cmbArt.itemData(self.cmbArt.currentIndex()))
        return art_id

    def getSelectedAlbum(self):
        if self.cmbAlb.count() > 0:
            alb_id = int(self.cmbAlb.itemData(self.cmbAlb.currentIndex()))
            return alb_id
        else:
            return None

    def setAlbumType(self):
        alb_id = self.getSelectedAlbum()
        c = self.conn.cursor()
        c.execute("SELECT albumtypeid, sourceid from album where albumid=%s;", (alb_id, ))
        typerow = c.fetchone()
        self.cmbType.setCurrentIndex(self.cmbType.findData(typerow[0]))
        self.cmbSource.setCurrentIndex(self.cmbSource.findData(typerow[1]))

    def populateArtCombo(self):
        c = self.conn.cursor()
        c.execute("SELECT distinct artist.ArtistID, ArtistName from Artist "
                  "inner join album on album.artistid = artist.artistid "
                  "order by ArtistName;")
        artlist = c.fetchall()

        for a in artlist:
            self.cmbArt.addItem(a[1], a[0])

    def populateAlbCombo(self):
        art_id = self.getSelectedArtist()
        if art_id is not None:
            c = self.conn.cursor()
            c.execute("SELECT AlbumID, Album from Album WHERE ArtistID={} order by Album;".format(art_id))
            alblist = c.fetchall()
            self.cmbAlb.clear()
            for a in alblist:
                self.cmbAlb.addItem(a[1], a[0])

    def populateTypeCombo(self):
        c = self.conn.cursor()
        c.execute("SELECT * from albumtype order by albumtypeid;")
        typelist = c.fetchall()

        for a in typelist:
            self.cmbType.addItem(a[1], a[0])

    def populateSourceCombo(self):
        c = self.conn.cursor()
        c.execute("SELECT * from source order by sourceid;")
        typelist = c.fetchall()

        for a in typelist:
            self.cmbSource.addItem(a[1], a[0])

    def clearTrackTable(self):
        while self.tableTracks.rowCount()>0:
            self.tableTracks.removeRow(0)

    def populateAlbumDetails(self):
        alb_id = self.getSelectedAlbum()
        if alb_id is not None:
            self.setAlbumType()
            c = self.conn.cursor()
            c.execute("SELECT Disc, Track, TrackTitle, Length, bonustrack from Track "
                      "WHERE albumid={} order by disc, track;".format(alb_id))
            tracklist = c.fetchall()
            self.clearTrackTable()
            for t in tracklist:
                rowpos = self.tableTracks.rowCount()
                self.tableTracks.insertRow(rowpos)
                for x in range(0, 5):
                    self.tableTracks.setItem(rowpos, x, QtWidgets.QTableWidgetItem(str(t[x])))


if __name__=="__main__":
    app = QtWidgets.QApplication(sys.argv)
    dialog = QtWidgets.QDialog()
    prog = QuickAdminForm(dialog)
    dialog.show()
    sys.exit(app.exec_())
