import sys
from PyQt5 import QtCore, QtGui, QtWidgets
import MySQLdb as mariadb
from quick_log_ui import Ui_Dialog

class QuickLogForm(Ui_Dialog):
    def __init__(self, dialog):
        Ui_Dialog.__init__(self)
        self.setupUi(dialog)
        self.conn = mariadb.connect(user='root', passwd='3amatBotMfO', db='Catalogue', use_unicode=True, charset='utf8')
        self.logDate.setDate(QtCore.QDate.currentDate())
        self.populateArtCombo()
        self.populateAlbCombo()

        self.cmbArt.currentIndexChanged.connect(self.populateAlbCombo)
        self.cmdLog.clicked.connect(self.saveLog)

    def populateArtCombo(self):
        c = self.conn.cursor()
        c.execute("SELECT ArtistID, ArtistName from Artist order by ArtistName;")
        artlist = c.fetchall()

        for a in artlist:
            self.cmbArt.addItem(a[1], a[0])


    def populateAlbCombo(self):
        art_id = self.getSelectedArtist()
        c = self.conn.cursor()
        c.execute("SELECT AlbumID, Album from Album WHERE ArtistID={} order by Album;".format(art_id))
        alblist = c.fetchall()
        self.cmbAlb.clear()
        for a in alblist:
            self.cmbAlb.addItem(a[1], a[0])

    def getSelectedArtist(self):
        art_id = int(self.cmbArt.itemData(self.cmbArt.currentIndex()))
        return art_id

    def getSelectedAlbum(self):
        alb_id = int(self.cmbAlb.itemData(self.cmbAlb.currentIndex()))
        return alb_id

    def saveLog(self):
        alb_id = self.getSelectedAlbum()
        log_date = self.logDate.date()

        sql = "INSERT INTO log (AlbumID, LogDate) VALUES ({},'{}')".format(alb_id, log_date.toString("yyyy-MM-dd"))
        c = self.conn.cursor()
        c.execute(sql)
        self.conn.commit()
        self.addHistory("Logged: " + self.cmbAlb.currentText())


    def addHistory(self, message):
        self.lstLog.insertItem(0, message)

if __name__=="__main__":
    app = QtWidgets.QApplication(sys.argv)
    dialog = QtWidgets.QDialog()
    prog = QuickLogForm(dialog)

    dialog.show()
    sys.exit(app.exec_())
