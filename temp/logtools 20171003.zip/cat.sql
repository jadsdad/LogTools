-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.2.9-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for view catalogue.chart_album_annual
DROP VIEW IF EXISTS `chart_album_annual`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `chart_album_annual` (
	`Y` INT(4) NULL,
	`albumid` INT(11) NOT NULL,
	`artistname` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`album` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`logtime` DECIMAL(54,0) NULL,
	`LogCount` BIGINT(21) NOT NULL
) ENGINE=MyISAM;

-- Dumping structure for view catalogue.chart_album_month
DROP VIEW IF EXISTS `chart_album_month`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `chart_album_month` (
	`y` INT(4) NULL,
	`m` INT(2) NULL,
	`albumid` INT(11) NOT NULL,
	`artistname` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`album` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`logtime` DECIMAL(54,0) NULL,
	`logcount` BIGINT(21) NOT NULL
) ENGINE=MyISAM;

-- Dumping structure for view catalogue.chart_artist_annual
DROP VIEW IF EXISTS `chart_artist_annual`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `chart_artist_annual` (
	`Y` INT(4) NULL,
	`ArtistName` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`LogTime` DECIMAL(54,0) NULL,
	`LogCount` BIGINT(21) NOT NULL
) ENGINE=MyISAM;

-- Dumping structure for view catalogue.chart_artist_month
DROP VIEW IF EXISTS `chart_artist_month`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `chart_artist_month` (
	`Y` INT(4) NULL,
	`M` INT(2) NULL,
	`ArtistName` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`LogTime` DECIMAL(54,0) NULL,
	`LogCount` BIGINT(21) NOT NULL
) ENGINE=MyISAM;

-- Dumping structure for table catalogue.label
DROP TABLE IF EXISTS `label`;
CREATE TABLE IF NOT EXISTS `label` (
  `LabelID` int(11) NOT NULL AUTO_INCREMENT,
  `LabelName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`LabelID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Dumping data for table catalogue.label: ~15 rows (approximately)
DELETE FROM `label`;
/*!40000 ALTER TABLE `label` DISABLE KEYS */;
INSERT INTO `label` (`LabelID`, `LabelName`) VALUES
	(1, 'Go! Discs'),
	(2, 'Utility'),
	(3, 'BBC'),
	(4, 'CBS / Columbia'),
	(5, 'Virgin'),
	(6, 'EMI'),
	(7, 'DJM'),
	(8, 'Portrait'),
	(9, 'WEA'),
	(10, 'EG'),
	(11, 'Charisma'),
	(12, 'A&M'),
	(13, 'Virgin EMI'),
	(14, 'UCJ'),
	(15, 'Mercury');
/*!40000 ALTER TABLE `label` ENABLE KEYS */;

-- Dumping structure for view catalogue.chart_album_annual
DROP VIEW IF EXISTS `chart_album_annual`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `chart_album_annual`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `chart_album_annual` AS SELECT 		Year(log.LogDate) as Y,
				album.albumid, 
				artist.artistname, 
				album.album, 
				SUM(albumlengths.albumlength) as logtime, 
				COUNT(log.LogID) as LogCount

FROM 			albumlengths 
					INNER JOIN album on albumlengths.AlbumID = album.AlbumID
					INNER JOIN log on log.AlbumID = album.AlbumID
					INNER JOIN artist on album.ArtistID = artist.ArtistID
					
WHERE			album.AlbumTypeID NOT IN (3, 4, 8)
GROUP BY		Y, artist.ArtistName, Album.Album
ORDER BY		Y, LogTime DESC, LogCount DESC ;

-- Dumping structure for view catalogue.chart_album_month
DROP VIEW IF EXISTS `chart_album_month`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `chart_album_month`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `chart_album_month` AS SELECT 		Year(log.LogDate) as y, 
				Month(log.LogDate) as m,
				album.albumid,
				artist.artistname, 
				album.album, 
				SUM(albumlengths.albumlength) as logtime, 
				COUNT(log.logID) as logcount

FROM 			albumlengths 
					INNER JOIN album on albumlengths.albumid = album.albumid
					INNER JOIN log on log.albumid = album.albumid
					INNER JOIN artist on album.artistid = artist.artistid
					
WHERE			album.albumtypeid NOT IN (3, 4, 8)
GROUP BY		y, m, artist.artistname, album.album
ORDER BY		y, m, logtime DESC, logcount DESC ;

-- Dumping structure for view catalogue.chart_artist_annual
DROP VIEW IF EXISTS `chart_artist_annual`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `chart_artist_annual`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `chart_artist_annual` AS SELECT 		Year(log.LogDate) as Y, 
				artist.ArtistName, 
				SUM(albumlengths.AlbumLength) as LogTime, 
				COUNT(log.LogID) as LogCount

FROM 			albumlengths 
					INNER JOIN album on albumlengths.AlbumID = album.AlbumID
					INNER JOIN log on log.AlbumID = album.AlbumID
					INNER JOIN artist on artist.ArtistID = album.ArtistID					
WHERE			album.AlbumTypeID NOT IN (3, 4, 8)
GROUP BY		Y, artist.ArtistName
ORDER BY		Y, LogTime DESC, LogCount DESC ;

-- Dumping structure for view catalogue.chart_artist_month
DROP VIEW IF EXISTS `chart_artist_month`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `chart_artist_month`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `chart_artist_month` AS SELECT 		Year(log.LogDate) as Y, 
				Month(log.LogDate) as M,
				artist.ArtistName, 
				SUM(albumlengths.AlbumLength) as LogTime, 
				COUNT(log.LogID) as LogCount

FROM 			albumlengths 
					INNER JOIN album on albumlengths.AlbumID = album.AlbumID
					INNER JOIN log on log.AlbumID = album.AlbumID
					INNER JOIN artist on artist.ArtistID = album.ArtistID					
WHERE			album.AlbumTypeID NOT IN (3, 4, 8)
GROUP BY		Y, M, artist.ArtistName
ORDER BY		Y, M, LogTime DESC, LogCount DESC ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
