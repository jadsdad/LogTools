import MySQLdb as mariadb
from pathlib import Path
import io

basedir = str(Path.home()) + "/Charts"
conn = mariadb.connect(user='root', passwd='3amatBotMfO', db='catalogue', use_unicode=True, charset='utf8')

def get_rows_from_sql(sql):
    cursor = conn.cursor()
    cursor.execute(sql)
    return cursor.fetchall()

def get_artists():
    sql = "SELECT * FROM chartstats_rolling order by artistname;"
    return get_rows_from_sql(sql)

def get_art_history(artname):
    artname_safe = artname.replace("'", "''")
    sql = "SELECT `index`, rank FROM rollingchart_table " \
          "where artistname='{}' order by `index`;".format(artname_safe)
    return get_rows_from_sql(sql)

def generate_report():
    f = io.open(basedir + "/Chart Stats - Rolling.txt","w",encoding='utf-8')
    art_list = get_artists()
    for art in art_list:
        art_name = art[0]
        peak = art[1]
        weeks = art[2]
        f.write("{0}\n{1}\n{0}\n\nPeak : {2:>3}\nWeeks: {3:>3}\n".format("=" * 80, art_name.upper(), peak, weeks))
        art_history = get_art_history(art_name)
        firstindex=0
        lastindex = 0
        movement=""
        lastposition = 0
        for h in art_history:
            index = h[0]
            r = h[1]
            firstindex = index if firstindex == 0 else firstindex
            if index == firstindex:
                f.write("\n")
                movement = "NE"
            elif index != (lastindex + 1):
                f.write("\n")
                movement = "RE"
            elif r == 1:
                movement = "**"
            elif r < lastposition:
                movement = "++"
            else:
                movement = ""

            lastposition = r

            f.write("\t\tWeek {:<20}{:>3}{:>5}\n".format(index, r, movement))
            lastindex = index
        f.write("\n\n")
    f.flush()
    f.close()

if __name__ == '__main__':
    generate_report()