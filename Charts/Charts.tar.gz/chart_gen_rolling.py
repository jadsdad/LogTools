#!/usr/bin/python3

import MySQLdb as mariadb
from pathlib import Path
import io
import os

basedir = str(Path.home()) + "/Charts/Rolling"
maxrank = 15

conn = mariadb.connect(user='root', passwd='3amatBotMfO', db='catalogue', use_unicode=True, charset='utf8')

def get_rows_from_sql(sql):
    cursor = conn.cursor()
    cursor.execute(sql)
    return cursor.fetchall()

def execute_sql(sql):
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()

def get_chart_data(index):
    sql = "SELECT * FROM rollingchart_table WHERE `index` = {}".format(index)
    return get_rows_from_sql(sql)

def get_dates(index):
    sql = "SELECT startdate, enddate FROM rolling4weeks WHERE `index`={}".format(index)
    return get_rows_from_sql(sql)[0]

def get_periods():
    sql = "SELECT DISTINCT `index` FROM rollingchart_table;"
    return get_rows_from_sql(sql)

def generate_filename(index, startdate, enddate):
    filename = "{}/Rolling Chart - Week #{} ({} to {})".format(basedir, index, startdate, enddate)
    filename = filename + ".txt"
    return filename

def get_previous_rank(index, artname):

    artname_safe = artname.replace("'","''")

    sql = "SELECT rank FROM rollingchart_table " \
          "where artistname='{}' and `index` = {};".format(artname_safe, index-1)

    output = get_rows_from_sql(sql)
    if len(output) == 0:
        return 0
    else:
        return output[0][0]

def main():

    if not os.path.exists(basedir):
        os.mkdir(basedir)

    execute_sql("CALL update_rollingchart()")
    periods = get_periods()

    for period in periods:
        index = period[0]
        startdate = get_dates(index)[0]
        enddate = get_dates(index)[1]

        f = io.open(generate_filename(index, startdate, enddate), "w", encoding="utf-8")
        chartdata = get_chart_data(index)
        for ranking in chartdata:
            rank = ranking[1]
            points = "{:,} pts".format(ranking[4])
            plays = "{:,} pls".format(ranking[5])
            artistname = ranking[3][0:50]

            lastrank = get_previous_rank(index, artistname)
            lastrankstr = ""
            if not lastrank == 0:
                if rank > lastrank:
                    movestr = "-"
                elif rank < lastrank:
                    movestr = "+"
                else:
                    movestr = "="

                lastrankstr = " ({}{})".format(movestr, lastrank)

            linestr = "{:<15}{:<50}{:>15}\n{:>80}\n".format(str(rank) + lastrankstr, artistname.upper(),
                                                                      points, plays)

            linestr += "-" * 80 + "\n"
            f.write(linestr)
            f.flush()
        f.close()

if __name__ == '__main__':
    main()
