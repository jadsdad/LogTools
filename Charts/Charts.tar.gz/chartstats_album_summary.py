import MySQLdb as mariadb
from datetime import date
from pathlib import Path
import io

basedir = str(Path.home()) + "/Charts"
ranktypes = ['Album - Month', 'Album - Year',
             "Album - This Year's Purchases",
             "Album - This Year's Releases",
             "EP - Year", "Album - Legacy"]

conn = mariadb.connect(user='root', passwd='3amatBotMfO', db='catalogue', use_unicode=True, charset='utf8')

def get_rows_from_sql(sql):
    cursor = conn.cursor()
    cursor.execute(sql)
    return cursor.fetchall()

def get_artists():
    sql = "SELECT DISTINCT artistname " \
          "FROM chartstats_view " \
          "WHERE album is not null order by artistname;"
    return get_rows_from_sql(sql)

def get_albums(artname):
    artname_safe = artname.replace("'", "''")
    sql = "SELECT DISTINCT album " \
          "FROM chartstats_view " \
          "WHERE artistname='{}' and ranktype='Album - All Time' order by rank;".format(artname_safe)
    return get_rows_from_sql(sql)

def get_rank(artname, album, ranktype, y):
    artname_safe = artname.replace("'", "''")
    album_safe = album.replace("'","''")
    ranktype_safe = ranktype.replace("'", "''")
    sql = "SELECT min(Rank) as Peak " \
          "FROM chartstats_view " \
          "WHERE artistname='{}' and album='{}' and ranktype='{}' and y={};".format(artname_safe, album_safe,
                                                                                    ranktype_safe, y)
    return get_rows_from_sql(sql)[0][0]


def get_art_history(artname, ranktype):
    artname_safe = artname.replace("'", "''")
    ranktype_safe = ranktype.replace("'", "''")

    sql = "SELECT y, m, album, rank FROM chartstats_view " \
          "where artistname='{}' and ranktype='{}' order by y, m, rank;".format(artname_safe, ranktype_safe)

    return get_rows_from_sql(sql)

def get_year_range(artname, album):
    artname_safe = artname.replace("'", "''")
    album_safe = album.replace("'","''")
    sql = "SELECT MIN(y) as yfrom, MAX(y) + 1 as yto FROM chartstats_view " \
          "WHERE artistname='{}' and album='{}' and y <> '0';".format(artname_safe, album_safe)
    row = get_rows_from_sql(sql)[0]
    if all(v is None for v in row):
        return 2018, date.today().year + 1
    else:
        return row[0], row[1]

def get_max_rank(y, m, ranktype):
    ranktype_safe = ranktype.replace("'", "''")
    sql = "SELECT MAX(rank) as maxrank from chartstats_view " \
          "where y={} and m={} and ranktype='{}';".format(y, m, ranktype_safe)
    return get_rows_from_sql(sql)[0][0]

def generate_report():
    f = io.open(basedir + "/Chart Stats - Album (Summary).txt","w",encoding='utf-8')

    art_list = get_artists()
    for art in art_list:
        art_name = art[0]
        f.write("{1}\n{0}\n{1}\n\n".format(art_name.upper(), "=" * 90))
        alb_list = get_albums(art_name)
        f.write("\t   AT  {:<50}   YR   LG   EP  TYR  TYP\n\n".format(""))
        lastalb = None
        for a in alb_list:
            alb = a[0]
            if alb is not None:
                yfrom, yto = get_year_range(art_name, alb)
                for y in range(yfrom, yto):
                    yr = get_rank(art_name, alb, "Album - Year", y)
                    ep = get_rank(art_name, alb, "EP - Year", y)
                    lg = get_rank(art_name, alb, "Album - Legacy", y)
                    ty = get_rank(art_name, alb, "Album - This Year's Releases", y)
                    tp = get_rank(art_name, alb, "Album - This Year's Purchases", y)
                    at = get_rank(art_name, alb, "Album - All Time", 0)
                    alb = alb[:35]
                    if alb != lastalb:
                        f.write("\t{:>5}  {:<40}{:<10}{:>5}{:>5}{:>5}{:>5}{:>5}\n".format("--" if at is None else at,
                                                                                          alb, y,
                                                                   "--" if yr is None else yr,
                                                                        "--" if lg is None else lg,
                                                                        "--" if ep is None else ep,
                                                                        "--" if ty is None else ty,
                                                                        "--" if tp is None else tp))
                    elif any(v is not None for v in [yr, ep, lg, ty, tp]):
                        f.write("\t{:>5}  {:<40}{:<10}{:>5}{:>5}{:>5}{:>5}{:>5}\n".format("","", y,
                                                                   "--" if yr is None else yr,
                                                                        "--" if lg is None else lg,
                                                                        "--" if ep is None else ep,
                                                                        "--" if ty is None else ty,
                                                                        "--" if tp is None else tp))

                    lastalb = alb

        f.write("\n\n")
    f.flush()
    f.close()

if __name__ == '__main__':
    generate_report()