import MySQLdb as mariadb
from datetime import date
from pathlib import Path
import io

basedir = str(Path.home()) + "/Charts"
ranktypes = ['Album - Month', 'Album - Year',
             "Album - This Year's Purchases",
             "Album - This Year's Releases",
             "EP - Year", "Album - Legacy"]

conn = mariadb.connect(user='root', passwd='3amatBotMfO', db='catalogue', use_unicode=True, charset='utf8')

def get_rows_from_sql(sql):
    cursor = conn.cursor()
    cursor.execute(sql)
    return cursor.fetchall()

def get_year_range(artname):
    artname_safe = artname.replace("'", "''")
    sql = "SELECT MIN(y) as yfrom, MAX(y) as yto FROM chartstats_view " \
          "WHERE artistname='{}' and y <> '0';".format(artname_safe)
    row = get_rows_from_sql(sql)[0]
    return row[0], row[1] + 1

def get_artists():
    sql = "SELECT DISTINCT artistname " \
          "FROM chartstats_view " \
          "WHERE album is not null order by artistname;"
    return get_rows_from_sql(sql)

def get_albums(artname):
    artname_safe = artname.replace("'", "''")
    sql = "SELECT DISTINCT album " \
          "FROM chartstats_view " \
          "WHERE artistname='{}' and ranktype='Album - All Time' order by rank;".format(artname_safe)
    return get_rows_from_sql(sql)

def get_rank(artname, ranktype, y):
    artname_safe = artname.replace("'", "''")
    ranktype_safe = ranktype.replace("'", "''")
    sql = "SELECT min(Rank) as Peak " \
          "FROM chartstats_view " \
          "WHERE artistname='{}' and ranktype='{}' and y={};".format(artname_safe, ranktype_safe, y)
    return get_rows_from_sql(sql)[0][0]


def get_art_history(artname, ranktype):
    artname_safe = artname.replace("'", "''")
    ranktype_safe = ranktype.replace("'", "''")

    sql = "SELECT y, m, album, rank FROM chartstats_view " \
          "where artistname='{}' and ranktype='{}' order by y, m, rank;".format(artname_safe, ranktype_safe)

    return get_rows_from_sql(sql)

def get_max_rank(y, m, ranktype):
    ranktype_safe = ranktype.replace("'", "''")
    sql = "SELECT MAX(rank) as maxrank from chartstats_view " \
          "where y={} and m={} and ranktype='{}';".format(y, m, ranktype_safe)
    return get_rows_from_sql(sql)[0][0]

def generate_report():
    f = io.open(basedir + "/Chart Stats - Artist (Summary).txt","w",encoding='utf-8')
    f.write("{0}\nARTIST SUMMARY\n{0}\n\n".format("=" * 80))
    f.write("-" * 80)
    f.write("\n\n\t   AT  {:<50}   YR   LG\n\n".format(""))

    art_list = get_artists()
    for art in art_list:
        art_name = art[0]
        lastart = None
        f.write("-" * 80 + "\n")
        yfrom, yto = get_year_range(art_name)
        for y in range(yfrom, yto):
            yr = get_rank(art_name, "Artist - Year", y)
            lg = get_rank(art_name, "Artist - Legacy", y)
            at = get_rank(art_name, "Artist - All Time", 0)
            if art_name != lastart:
                f.write("\t{:>5}  {:<40}{:<10}{:>5}{:>5}\n".format("--" if at is None else at, art_name.upper(), y,
                                                                   "--" if yr is None else yr,
                                                                    "--" if lg is None else lg))
            elif any(v is not None for v in [yr, lg]):
                f.write("\t{:>5}  {:<40}{:<10}{:>5}{:>5}\n".format("","", y, "--" if yr is None else yr,
                                                                   "--" if lg is None else lg))

            lastart = art_name

    f.flush()
    f.close()

if __name__ == '__main__':
    generate_report()